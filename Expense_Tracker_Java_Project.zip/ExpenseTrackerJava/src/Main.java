import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Personal Expense Tracker
 * A simple Swing desktop application with CSV persistence.
 */
public class Main extends JFrame {
    private static final String DATA_FILE = "expenses.csv";
    private final List<Expense> expenses = new ArrayList<>();
    private final DefaultTableModel tableModel = new DefaultTableModel(
        new String[]{"Date", "Category", "Description", "Amount (₹)"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(tableModel);
    private final JLabel totalLabel = new JLabel("Total spent: ₹0.00");
    private final JComboBox<String> filterBox = new JComboBox<>(
        new String[]{"All categories", "Food", "Travel", "Shopping", "Bills", "Education", "Health", "Other"});

    public Main() {
        super("Expense Tracker");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(12, 12));

        JLabel heading = new JLabel("EXPENSE TRACKER");
        heading.setFont(new Font("SansSerif", Font.BOLD, 25));
        heading.setBorder(BorderFactory.createEmptyBorder(18, 20, 4, 20));
        add(heading, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(8, 8));
        center.setBorder(BorderFactory.createEmptyBorder(8, 20, 12, 20));
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addButton = new JButton("Add expense");
        JButton deleteButton = new JButton("Delete selected");
        JButton refreshButton = new JButton("Refresh");
        toolbar.add(addButton);
        toolbar.add(deleteButton);
        toolbar.add(new JLabel("Filter:"));
        toolbar.add(filterBox);
        toolbar.add(refreshButton);
        center.add(toolbar, BorderLayout.NORTH);

        table.setRowHeight(30);
        table.setFillsViewportHeight(true);
        center.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        footer.add(totalLabel, BorderLayout.WEST);
        JLabel note = new JLabel("Data is saved locally in expenses.csv");
        note.setForeground(Color.GRAY);
        footer.add(note, BorderLayout.EAST);
        center.add(footer, BorderLayout.SOUTH);
        add(center, BorderLayout.CENTER);

        addButton.addActionListener(e -> addExpense());
        deleteButton.addActionListener(e -> deleteSelected());
        refreshButton.addActionListener(e -> refreshTable());
        filterBox.addActionListener(e -> refreshTable());

        loadExpenses();
        refreshTable();
    }

    private void addExpense() {
        JTextField dateField = new JTextField(LocalDate.now().toString());
        JComboBox<String> categoryField = new JComboBox<>(
            new String[]{"Food", "Travel", "Shopping", "Bills", "Education", "Health", "Other"});
        JTextField descriptionField = new JTextField();
        JTextField amountField = new JTextField();

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Date (YYYY-MM-DD):")); form.add(dateField);
        form.add(new JLabel("Category:")); form.add(categoryField);
        form.add(new JLabel("Description:")); form.add(descriptionField);
        form.add(new JLabel("Amount (₹):")); form.add(amountField);

        int result = JOptionPane.showConfirmDialog(this, form, "Add a new expense",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        try {
            LocalDate date = LocalDate.parse(dateField.getText().trim());
            String category = (String) categoryField.getSelectedItem();
            String description = descriptionField.getText().trim();
            double amount = Double.parseDouble(amountField.getText().trim());
            if (description.isEmpty() || amount <= 0 || !Double.isFinite(amount)) {
                throw new IllegalArgumentException("Enter a description and an amount greater than zero.");
            }
            expenses.add(new Expense(date, category, description, amount));
            saveExpenses();
            refreshTable();
        } catch (DateTimeParseException ex) {
            showError("Date must be valid and use YYYY-MM-DD format.");
        } catch (NumberFormatException ex) {
            showError("Amount must be a valid number.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            showError("Select an expense to delete.");
            return;
        }
        String date = tableModel.getValueAt(row, 0).toString();
        String category = tableModel.getValueAt(row, 1).toString();
        String description = tableModel.getValueAt(row, 2).toString();
        for (int i = 0; i < expenses.size(); i++) {
            Expense x = expenses.get(i);
            if (x.date.toString().equals(date) && x.category.equals(category)
                && x.description.equals(description)) {
                expenses.remove(i);
                break;
            }
        }
        saveExpenses();
        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        String filter = (String) filterBox.getSelectedItem();
        double total = 0;
        for (Expense x : expenses) {
            if ("All categories".equals(filter) || x.category.equals(filter)) {
                tableModel.addRow(new Object[]{x.date, x.category, x.description,
                    String.format("%.2f", x.amount)});
                total += x.amount;
            }
        }
        totalLabel.setText(String.format("Total spent: ₹%.2f", total));
    }

    private void loadExpenses() {
        Path path = Paths.get(DATA_FILE);
        if (!Files.exists(path)) return;
        try (BufferedReader reader = Files.newBufferedReader(path)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split(",", 4);
                if (p.length == 4) {
                    try {
                        expenses.add(new Expense(LocalDate.parse(p[0]), p[1],
                            p[2], Double.parseDouble(p[3])));
                    } catch (RuntimeException ignored) { /* Skip malformed rows. */ }
                }
            }
        } catch (IOException ex) {
            showError("Could not read saved expenses: " + ex.getMessage());
        }
    }

    private void saveExpenses() {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(DATA_FILE))) {
            for (Expense x : expenses) {
                writer.write(x.date + "," + x.category + "," +
                    x.description.replace(",", " ") + "," + x.amount);
                writer.newLine();
            }
        } catch (IOException ex) {
            showError("Could not save expenses: " + ex.getMessage());
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Expense Tracker",
            JOptionPane.ERROR_MESSAGE);
    }

    private static class Expense {
        LocalDate date;
        String category, description;
        double amount;
        Expense(LocalDate date, String category, String description, double amount) {
            this.date = date; this.category = category;
            this.description = description; this.amount = amount;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}
