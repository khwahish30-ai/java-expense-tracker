# Personal Expense Tracker (Java)

A Java Swing desktop application for recording and reviewing personal expenses.

## Features
- Add an expense with date, category, description and amount
- Delete a selected expense
- Filter records by category
- View the total for the currently displayed records
- Save and reload records from a local `expenses.csv` file

## Requirements
- JDK 8 or later
- No external libraries

## Run
Open a terminal in the `src` folder and run:

```bash
javac Main.java
java Main
```

The application creates/updates `expenses.csv` in the working directory. Keep the CSV file if you want to retain your records.

## Notes
This is a compact academic project. The CSV format is intended for simple descriptions; commas in descriptions are replaced with spaces when saving.
